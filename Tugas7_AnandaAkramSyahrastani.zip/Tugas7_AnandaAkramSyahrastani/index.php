<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">

    <link rel="stylesheet" href="https://grapedrop.com/css/gjs-base.css?id=d0383dd1e92b8b8ea83e">

    <link rel="stylesheet" href="css/style.css">

</head>

<body>
    <div id="i34v" class="gpd-box">
        <div id="imdo" class="gpd-text">Kalkulator Sederhana</div>
    </div>
    <div id="irez" class="gpd-box">
        <form method="post" id="i07w" data-redirect="" class="form" action="./app/counted.php">
            <div class="form-group">
                <input type="number" placeholder="Input Bilangan 1" name="bilangan_1" id="i53by" value="0" class="input" />
                <input type="number" placeholder="Input Bilangan 2" name="bilangan_2" id="i2b8x" value="0" class="input" />
            </div>
            <div id="ivs8z" class="form-group"><button type="submit" id="iiz9n" class="button">Hitung</button></div>
        </form>
    </div>

</body>

</html>