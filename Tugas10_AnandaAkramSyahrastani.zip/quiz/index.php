<?php 
require './application/controller/Tiket.php';

$root = new Tiket;

$root->index();

?>