This project using Bootrap 5.3 through CDN.
Please check out application/view/template folder to see the CDN links